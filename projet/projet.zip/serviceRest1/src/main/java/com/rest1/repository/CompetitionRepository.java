package com.rest1.repository;

import org.springframework.data.repository.CrudRepository;

import com.rest1.model.Competition;

public interface CompetitionRepository extends CrudRepository<Competition, Integer> {

}
