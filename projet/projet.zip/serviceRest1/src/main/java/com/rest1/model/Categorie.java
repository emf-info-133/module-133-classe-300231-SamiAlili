package com.rest1.model;

public enum Categorie {
    FEMME, HOMME, SPORT, LUXE
}
