package com.rest1.model;

public enum Etat {
    INSCRIPTION, VOTATION, TERMINE
}
