Code du service REST 1
