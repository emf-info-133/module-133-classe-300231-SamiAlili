package com.gw.gw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GwApplicationTests {

	@Test
	void contextLoads() {
	}

}
