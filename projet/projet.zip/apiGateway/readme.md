Code de l'ApiGateway
