Code du service REST 2
